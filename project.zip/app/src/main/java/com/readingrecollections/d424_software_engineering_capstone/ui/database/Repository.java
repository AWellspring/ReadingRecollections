package com.readingrecollections.d424_software_engineering_capstone.ui.database;

import static com.readingrecollections.d424_software_engineering_capstone.ui.database.DateConverter.fromLocalDate;

import android.app.Application;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.function.Consumer;

import com.readingrecollections.d424_software_engineering_capstone.ui.dao.AuthorDao;
import com.readingrecollections.d424_software_engineering_capstone.ui.dao.BookDao;
import com.readingrecollections.d424_software_engineering_capstone.ui.entities.Author;
import com.readingrecollections.d424_software_engineering_capstone.ui.entities.Book;
import com.readingrecollections.d424_software_engineering_capstone.ui.userinterface.DateHeader;
import com.readingrecollections.d424_software_engineering_capstone.ui.userinterface.GenreHeader;
import com.readingrecollections.d424_software_engineering_capstone.ui.userinterface.Item;
import com.readingrecollections.d424_software_engineering_capstone.ui.userinterface.SeriesNameHeader;
import com.readingrecollections.d424_software_engineering_capstone.ui.userinterface.TitleHeader;

// Manages operations between the UI and the database
public class Repository {

    // Allows access to author database operations
    private AuthorDao mAuthorDao;

    // Allows access to book database operations
    private BookDao mBookDao;

    // Handles background task execution without blocking the main thread
    public Executor executor;

    // Initializes the repository
    // Calls the DatabaseBuilder and passes through the book and author daos
    // Assigns the single-thread executor
    public Repository(Application application){
        DatabaseBuilder db = DatabaseBuilder.getDatabase(application);
        mBookDao = db.bookDao();
        mAuthorDao = db.authorDao();

        executor = Executors.newSingleThreadExecutor();
    }

    // Overloaded constructor for testing
    public Repository(Application application, DatabaseBuilder databaseBuilder){
        mBookDao = databaseBuilder.bookDao();
        mAuthorDao = databaseBuilder.authorDao();

        executor = Executors.newSingleThreadExecutor();
    }

    // Adds an author to the database if they don't already exist
    public void insertAuthorIfNotExists(Author author, Runnable onSuccess, Runnable onAuthorExists) {
        executor.execute(() -> {
            // Generates the author's full name
            author.updateFullName();

            // Check if the author already exists by comparing full name
            Author existingAuthor = mAuthorDao.getAuthorByName(author.getAuthorFullName());

            if (existingAuthor == null) {
                // Author does not exist, so they are added
                mAuthorDao.insert(author);

                // Returns success runnable, prompting success Toast
                if (onSuccess != null) {
                    onSuccess.run();
                }
            }

            // Returns author exists runnable, prompting author exists Toast
            else {
                if (onAuthorExists != null) {
                    onAuthorExists.run();
                }
            }
        });
    }

    public void updateAuthor(Author author) {
        executor.execute(() -> {
            mAuthorDao.update(author);
        });
    }

    public void deleteAuthor(Author author) {
        executor.execute(() -> {
            mAuthorDao.delete(author);
        });
    }

    public void insertBook(Book book, Runnable onSuccess, Runnable onFailure) {
        executor.execute(() -> {
            try {
                // Insert the book into the database
                mBookDao.insert(book);

                if (onSuccess != null) {
                    onSuccess.run();
                }
            } catch (Exception e) {
                // In case of an error, run the failure callback on the UI thread
                onFailure.run();
            }
        });
    }

    public void updateBook(Book book) {
        executor.execute(() -> {
            mBookDao.update(book);
        });
    }

    public void deleteBook(Book book) {
        executor.execute(() -> {
            mBookDao.delete(book);
        });
    }

    // Returns author whose name matches
    public Author getAuthorByName(String fullName) {
        return mAuthorDao.getAuthorByName(fullName);
    }

    public int getAuthorIdByName(String fullName) {
        return mAuthorDao.getAuthorIdByName(fullName);
    }

    // Returns a list of all author names
    public List<String> getAllAuthorNames() {
        return mAuthorDao.getAllAuthorNames();
    }

    // Returns a list of all books
    public List<Book> getAllBooks() {
        return mBookDao.getAllBooks();
    }

    // Returns a list of all series names
    public List<String> getAllSeriesNames() {
        return mBookDao.getAllSeriesNames();
    }

    // Returns a list of all genres
    public List<String> getAllGenres() {
        return mBookDao.getAllGenres();
    }

    // Returns a list of all authors; accessed by the RecyclerView
    // Will pass author information along to author details page
    public List<Author> getAllAuthors() {
        return mAuthorDao.getAllAuthors();
    }

    public List<Book> getBooksByAuthor(int authorId) {
        return mBookDao.getBooksByAuthor(authorId);
    }

    // Returns the book which matches the title and author id
    public Book getBookByTitleAndAuthor(String bookTitle, int authorId) {
        return mBookDao.getBookByTitleAndAuthor(bookTitle, authorId);
    }

    public String getAuthorNameById(int authorId) {
        return mAuthorDao.getAuthorNameById(authorId);
    }

    public List<Book> getBooksGroupedByAuthor() {
        return mBookDao.getBooksGroupedByAuthor();
    }

    public List<Book> getBooksGroupedByAuthorLastName() {
        return mBookDao.getBooksGroupedByAuthorLastName();
    }

    public List<Book> getBooksGroupedByGenre() {
        return mBookDao.getBooksGroupedByGenre();
    }

    public List<Book> getBooksGroupedByDate() {
        return mBookDao.getBooksGroupedByDate();
    }

    public List<Book> searchBooks(String query) {
        return mBookDao.searchBooks(query);
    }

    public List<Author> searchAuthors(String query) {
        return mAuthorDao.searchAuthors(query);
    }

    public void getItemsGroupedByAuthor(Consumer<List<Item>> callback) {
        Executors.newSingleThreadExecutor().execute(() -> {
            List<Book> bookList = mBookDao.getBooksGroupedByAuthor();
            List<Item> itemList = new ArrayList<>();
            int lastAuthorId = -1;

            for (Book book : bookList) {
                if (book.getAuthorId() != lastAuthorId) {
                    // Fetch author details
                    Author author = mAuthorDao.getAuthorById(book.getAuthorId());
                    itemList.add(author); // Add author as header
                    lastAuthorId = book.getAuthorId();
                }
                itemList.add(book); // Add book under the correct author
            }

            callback.accept(itemList); // Pass the data back to the caller
        });
    }

    public void getItemsGroupedByAuthorLastName(Consumer<List<Item>> callback) {
        Executors.newSingleThreadExecutor().execute(() -> {
            List<Book> bookList = mBookDao.getBooksGroupedByAuthorLastName();
            List<Item> itemList = new ArrayList<>();
            int lastAuthorId = -1;

            for (Book book : bookList) {
                if (book.getAuthorId() != lastAuthorId) {
                    // Fetch author details
                    Author author = mAuthorDao.getAuthorById(book.getAuthorId());
                    itemList.add(author); // Add author as header
                    lastAuthorId = book.getAuthorId();
                }
                itemList.add(book); // Add book under the correct author
            }

            callback.accept(itemList); // Pass the data back to the caller
        });
    }

    public void getItemsGroupedByGenre(Consumer<List<Item>> callback) {
        Executors.newSingleThreadExecutor().execute(() -> {
            List<Book> bookList = mBookDao.getBooksGroupedByGenre();
            List<Item> itemList = new ArrayList<>();
            String lastGenre = null;

            for (Book book : bookList) {
                // Skip books without a genre
                if (book.getGenre() == null || book.getGenre().trim().isEmpty()) {
                    continue;
                }
                if (!book.getGenre().equals(lastGenre)) {
                    // Fetch book details
                    itemList.add(new GenreHeader(book.getGenre()));
                    lastGenre = book.getGenre();
                }
                itemList.add(book);
            }
            callback.accept(itemList);
        });
    }

    public void getItemsGroupedBySeries(Consumer<List<Item>> callback) {
        Executors.newSingleThreadExecutor().execute(() -> {
            List<Book> bookList = mBookDao.getBooksGroupedBySeries();
            List<Item> itemList = new ArrayList<>();
            String lastSeries = null;

            for (Book book : bookList) {
                // Skip books without a series name
                if (book.getSeriesName() == null || book.getSeriesName().trim().isEmpty()) {
                    continue;
                }
                if (!book.getSeriesName().equals(lastSeries)) {
                    // Fetch book details
                    itemList.add(new SeriesNameHeader(book.getSeriesName()));
                    lastSeries = book.getSeriesName();
                }
                itemList.add(book);
            }
            callback.accept(itemList);
        });
    }

    public void getItemsGroupedByDate(Consumer<List<Item>> callback) {
        Executors.newSingleThreadExecutor().execute(() -> {
            List<Book> bookList = mBookDao.getBooksGroupedByDate();
            Map<LocalDate, List<Book>> bookMap = new TreeMap<>(Collections.reverseOrder());

            for (Book book : bookList) {
                if (book.getDateRead() == null) continue;

                LocalDate date = DateConverter.fromString(DateConverter.fromLocalDate(book.getDateRead()));
                bookMap.putIfAbsent(date, new ArrayList<>());
                bookMap.get(date).add(book);
            }


            List<Item> itemList = new ArrayList<>();
            for (Map.Entry<LocalDate, List<Book>> entry : bookMap.entrySet()) {
                String formattedDate = fromLocalDate(entry.getKey());
                itemList.add(new DateHeader(formattedDate));
                itemList.addAll(entry.getValue());
            }

            callback.accept(itemList);
        });
    }

        public void getItemsGroupedByTitle(Consumer<List<Item>> callback) {
            Executors.newSingleThreadExecutor().execute(() -> {
                List<Book> bookList = mBookDao.getAllBooks();
                List<Item> itemList = new ArrayList<>();
                char lastChar = '\u0000';

                for (Book book : bookList) {
                    // Skip books without a title
                    if (book.getTitle() == null || book.getTitle().trim().isEmpty()) {
                        continue;
                    }
                    char currChar = book.getTitle().charAt(0);
                    if (currChar != lastChar) {
                        // Fetch book details
                        itemList.add(new TitleHeader(currChar));
                        lastChar = currChar;
                    }
                    itemList.add(book);
                }
                callback.accept(itemList);
            });
    }

    public void getItemsGroupedByTitleDesc(Consumer<List<Item>> callback) {
        Executors.newSingleThreadExecutor().execute(() -> {
            List<Book> bookList = mBookDao.getAllBooks();
            List<Item> itemList = new ArrayList<>();


            bookList.sort((b1, b2) -> {
                char firstLetter1 = b1.getTitle().charAt(0);
                char firstLetter2 = b2.getTitle().charAt(0);
                return Character.compare(firstLetter2, firstLetter1);
            });


            char lastChar = '\u0000';

            for (Book book : bookList) {
                if (book.getTitle() == null || book.getTitle().trim().isEmpty()) {
                    continue;
                }

                char currChar = book.getTitle().charAt(0);

                if (currChar != lastChar) {
                    itemList.add(new TitleHeader(currChar));
                    lastChar = currChar;
                }

                itemList.add(book);
            }

            callback.accept(itemList);
        });
    }
}